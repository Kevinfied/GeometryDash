public class Slab {

    private int x, y;
    public static int width = 75;
    public static int height = 37;

    public Slab() {



    }

    public void draw() {

    }

}