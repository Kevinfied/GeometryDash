public class Globals {

    public static final int SCREEN_WIDTH = 1250;
    public static final int SCREEN_HEIGHT = 800;

    public static final int floor = SCREEN_HEIGHT-150;

    public static final int gridWidth = 75;
    public static final int slabWidth = 75;
    public static final int slabHeight = 37;
    public static final int solidWidth = 75;
    public static final int solidHeight = 75;

    public static final int SHIP_CEILING =Globals.floor - Globals.solidHeight * 11 + 35;

}
